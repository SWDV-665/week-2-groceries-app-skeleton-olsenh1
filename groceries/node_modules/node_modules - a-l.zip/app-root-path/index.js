'use strict';

var lib = require('./lib/app-root-path.js');
module.exports = lib(__dirname);