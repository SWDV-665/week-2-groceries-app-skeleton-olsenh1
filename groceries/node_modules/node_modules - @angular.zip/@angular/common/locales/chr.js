/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(null, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define("@angular/common/locales/chr", ["require", "exports"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    // THIS CODE IS GENERATED - DO NOT MODIFY
    // See angular/tools/gulp-tasks/cldr/extract.js
    var u = undefined;
    function plural(n) {
        if (n === 1)
            return 1;
        return 5;
    }
    exports.default = [
        'chr', [['Ꮜ', 'Ꮢ'], ['ᏌᎾᎴ', 'ᏒᎯᏱᎢ'], ['ᏌᎾᎴ', 'ᏒᎯᏱᎢᏗᏢ']],
        [['ᏌᎾᎴ', 'ᏒᎯᏱᎢ'], u, ['ᏌᎾᎴ', 'ᏒᎯᏱᎢᏗᏢ']],
        [
            ['Ꮖ', 'Ꮙ', 'Ꮤ', 'Ꮶ', 'Ꮕ', 'Ꮷ', 'Ꭴ'],
            ['ᏆᏍᎬ', 'ᏉᏅᎯ', 'ᏔᎵᏁ', 'ᏦᎢᏁ', 'ᏅᎩᏁ', 'ᏧᎾᎩ', 'ᏈᏕᎾ'],
            [
                'ᎤᎾᏙᏓᏆᏍᎬ', 'ᎤᎾᏙᏓᏉᏅᎯ', 'ᏔᎵᏁᎢᎦ', 'ᏦᎢᏁᎢᎦ',
                'ᏅᎩᏁᎢᎦ', 'ᏧᎾᎩᎶᏍᏗ', 'ᎤᎾᏙᏓᏈᏕᎾ'
            ],
            ['ᏍᎬ', 'ᏅᎯ', 'ᏔᎵ', 'ᏦᎢ', 'ᏅᎩ', 'ᏧᎾ', 'ᏕᎾ']
        ],
        u,
        [
            ['Ꭴ', 'Ꭷ', 'Ꭰ', 'Ꭷ', 'Ꭰ', 'Ꮥ', 'Ꭻ', 'Ꭶ', 'Ꮪ', 'Ꮪ', 'Ꮕ', 'Ꭵ'],
            [
                'ᎤᏃ', 'ᎧᎦ', 'ᎠᏅ', 'ᎧᏬ', 'ᎠᏂ', 'ᏕᎭ', 'ᎫᏰ', 'ᎦᎶ', 'ᏚᎵ',
                'ᏚᏂ', 'ᏅᏓ', 'ᎥᏍ'
            ],
            [
                'ᎤᏃᎸᏔᏅ', 'ᎧᎦᎵ', 'ᎠᏅᏱ', 'ᎧᏬᏂ', 'ᎠᏂᏍᎬᏘ', 'ᏕᎭᎷᏱ',
                'ᎫᏰᏉᏂ', 'ᎦᎶᏂ', 'ᏚᎵᏍᏗ', 'ᏚᏂᏅᏗ', 'ᏅᏓᏕᏆ', 'ᎥᏍᎩᏱ'
            ]
        ],
        u, [['BC', 'AD'], u, ['ᏧᏓᎷᎸ ᎤᎷᎯᏍᏗ ᎦᎶᏁᏛ', 'ᎠᏃ ᏙᎻᏂ']], 0,
        [6, 0], ['M/d/yy', 'MMM d, y', 'MMMM d, y', 'EEEE, MMMM d, y'],
        ['h:mm a', 'h:mm:ss a', 'h:mm:ss a z', 'h:mm:ss a zzzz'], ['{1}, {0}', u, '{1} ᎤᎾᎢ {0}', u],
        ['.', ',', ';', '%', '+', '-', 'E', '×', '‰', '∞', 'NaN', ':'],
        ['#,##0.###', '#,##0%', '¤#,##0.00', '#E0'], '$', 'US ᎠᏕᎳ', { 'JPY': ['JP¥', '¥'] }, plural
    ];
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcGFja2FnZXMvY29tbW9uL2xvY2FsZXMvY2hyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7R0FNRzs7Ozs7Ozs7Ozs7O0lBRUgseUNBQXlDO0lBQ3pDLCtDQUErQztJQUUvQyxJQUFNLENBQUMsR0FBRyxTQUFTLENBQUM7SUFFcEIsU0FBUyxNQUFNLENBQUMsQ0FBUztRQUN2QixJQUFJLENBQUMsS0FBSyxDQUFDO1lBQUUsT0FBTyxDQUFDLENBQUM7UUFDdEIsT0FBTyxDQUFDLENBQUM7SUFDWCxDQUFDO0lBRUQsa0JBQWU7UUFDYixLQUFLLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQztRQUN2RCxDQUFDLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQztRQUN2QztZQUNFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDO1lBQ25DLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO1lBQ2pEO2dCQUNFLFNBQVMsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLE9BQU87Z0JBQ3RDLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUzthQUM3QjtZQUNELENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDO1NBQzNDO1FBQ0QsQ0FBQztRQUNEO1lBQ0UsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQztZQUM1RDtnQkFDRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUk7Z0JBQ3BELElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSTthQUNqQjtZQUNEO2dCQUNFLE9BQU8sRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsTUFBTTtnQkFDN0MsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNO2FBQzlDO1NBQ0Y7UUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxpQkFBaUIsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDdEQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxRQUFRLEVBQUUsVUFBVSxFQUFFLFdBQVcsRUFBRSxpQkFBaUIsQ0FBQztRQUM5RCxDQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsYUFBYSxFQUFFLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxFQUFFLGFBQWEsRUFBRSxDQUFDLENBQUM7UUFDM0YsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLEdBQUcsQ0FBQztRQUM5RCxDQUFDLFdBQVcsRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLEtBQUssQ0FBQyxFQUFFLEdBQUcsRUFBRSxRQUFRLEVBQUUsRUFBQyxLQUFLLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLEVBQUMsRUFBRSxNQUFNO0tBQzFGLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgR29vZ2xlIEluYy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuICogZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZSBhdCBodHRwczovL2FuZ3VsYXIuaW8vbGljZW5zZVxuICovXG5cbi8vIFRISVMgQ09ERSBJUyBHRU5FUkFURUQgLSBETyBOT1QgTU9ESUZZXG4vLyBTZWUgYW5ndWxhci90b29scy9ndWxwLXRhc2tzL2NsZHIvZXh0cmFjdC5qc1xuXG5jb25zdCB1ID0gdW5kZWZpbmVkO1xuXG5mdW5jdGlvbiBwbHVyYWwobjogbnVtYmVyKTogbnVtYmVyIHtcbiAgaWYgKG4gPT09IDEpIHJldHVybiAxO1xuICByZXR1cm4gNTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgW1xuICAnY2hyJywgW1sn4Y+MJywgJ+GPkiddLCBbJ+GPjOGOvuGOtCcsICfhj5Lhjq/hj7HhjqInXSwgWyfhj4zhjr7hjrQnLCAn4Y+S4Y6v4Y+x4Y6i4Y+X4Y+iJ11dLFxuICBbWyfhj4zhjr7hjrQnLCAn4Y+S4Y6v4Y+x4Y6iJ10sIHUsIFsn4Y+M4Y6+4Y60JywgJ+GPkuGOr+GPseGOouGPl+GPoiddXSxcbiAgW1xuICAgIFsn4Y+GJywgJ+GPiScsICfhj5QnLCAn4Y+mJywgJ+GPhScsICfhj6cnLCAn4Y6kJ10sXG4gICAgWyfhj4bhj43hjqwnLCAn4Y+J4Y+F4Y6vJywgJ+GPlOGOteGPgScsICfhj6bhjqLhj4EnLCAn4Y+F4Y6p4Y+BJywgJ+GPp+GOvuGOqScsICfhj4jhj5Xhjr4nXSxcbiAgICBbXG4gICAgICAn4Y6k4Y6+4Y+Z4Y+T4Y+G4Y+N4Y6sJywgJ+GOpOGOvuGPmeGPk+GPieGPheGOrycsICfhj5ThjrXhj4HhjqLhjqYnLCAn4Y+m4Y6i4Y+B4Y6i4Y6mJyxcbiAgICAgICfhj4Xhjqnhj4HhjqLhjqYnLCAn4Y+n4Y6+4Y6p4Y624Y+N4Y+XJywgJ+GOpOGOvuGPmeGPk+GPiOGPleGOvidcbiAgICBdLFxuICAgIFsn4Y+N4Y6sJywgJ+GPheGOrycsICfhj5ThjrUnLCAn4Y+m4Y6iJywgJ+GPheGOqScsICfhj6fhjr4nLCAn4Y+V4Y6+J11cbiAgXSxcbiAgdSxcbiAgW1xuICAgIFsn4Y6kJywgJ+GOpycsICfhjqAnLCAn4Y6nJywgJ+GOoCcsICfhj5UnLCAn4Y6rJywgJ+GOpicsICfhj5onLCAn4Y+aJywgJ+GPhScsICfhjqUnXSxcbiAgICBbXG4gICAgICAn4Y6k4Y+DJywgJ+GOp+GOpicsICfhjqDhj4UnLCAn4Y6n4Y+sJywgJ+GOoOGPgicsICfhj5Xhjq0nLCAn4Y6r4Y+wJywgJ+GOpuGOticsICfhj5rhjrUnLFxuICAgICAgJ+GPmuGPgicsICfhj4Xhj5MnLCAn4Y6l4Y+NJ1xuICAgIF0sXG4gICAgW1xuICAgICAgJ+GOpOGPg+GOuOGPlOGPhScsICfhjqfhjqbhjrUnLCAn4Y6g4Y+F4Y+xJywgJ+GOp+GPrOGPgicsICfhjqDhj4Lhj43hjqzhj5gnLCAn4Y+V4Y6t4Y634Y+xJyxcbiAgICAgICfhjqvhj7Dhj4nhj4InLCAn4Y6m4Y624Y+CJywgJ+GPmuGOteGPjeGPlycsICfhj5rhj4Lhj4Xhj5cnLCAn4Y+F4Y+T4Y+V4Y+GJywgJ+GOpeGPjeGOqeGPsSdcbiAgICBdXG4gIF0sXG4gIHUsIFtbJ0JDJywgJ0FEJ10sIHUsIFsn4Y+n4Y+T4Y634Y64IOGOpOGOt+GOr+GPjeGPlyDhjqbhjrbhj4Hhj5snLCAn4Y6g4Y+DIOGPmeGOu+GPgiddXSwgMCxcbiAgWzYsIDBdLCBbJ00vZC95eScsICdNTU0gZCwgeScsICdNTU1NIGQsIHknLCAnRUVFRSwgTU1NTSBkLCB5J10sXG4gIFsnaDptbSBhJywgJ2g6bW06c3MgYScsICdoOm1tOnNzIGEgeicsICdoOm1tOnNzIGEgenp6eiddLCBbJ3sxfSwgezB9JywgdSwgJ3sxfSDhjqThjr7hjqIgezB9JywgdV0sXG4gIFsnLicsICcsJywgJzsnLCAnJScsICcrJywgJy0nLCAnRScsICfDlycsICfigLAnLCAn4oieJywgJ05hTicsICc6J10sXG4gIFsnIywjIzAuIyMjJywgJyMsIyMwJScsICfCpCMsIyMwLjAwJywgJyNFMCddLCAnJCcsICdVUyDhjqDhj5XhjrMnLCB7J0pQWSc6IFsnSlDCpScsICfCpSddfSwgcGx1cmFsXG5dO1xuIl19