// mock cordova.js
