# @ionic/angular-toolkit

[![semantic-release](https://img.shields.io/badge/%20%20%F0%9F%93%A6%F0%9F%9A%80-semantic--release-e10079.svg)](https://github.com/semantic-release/semantic-release)
[![Dependabot Status](https://api.dependabot.com/badges/status?host=github&identifier=151767795)](https://dependabot.com)
[![npm](https://img.shields.io/npm/v/@ionic/angular-toolkit.svg)](https://www.npmjs.com/package/@ionic/angular-toolkit)

 Angular Schematics and Builders for `@ionic/angular` apps.
