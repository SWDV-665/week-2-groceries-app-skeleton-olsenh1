export declare function buildSelector(options: any, projectPrefix: string): string;
