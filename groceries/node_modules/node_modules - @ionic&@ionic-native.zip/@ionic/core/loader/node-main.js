
module.exports.applyPolyfills = function() { return Promise.resolve() };
module.exports.defineCustomElements = function() { return Promise.resolve() };
