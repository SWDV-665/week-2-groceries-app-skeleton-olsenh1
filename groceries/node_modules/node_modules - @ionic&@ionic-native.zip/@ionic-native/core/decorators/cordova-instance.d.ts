import { CordovaOptions } from './interfaces';
export declare function cordovaInstance(pluginObj: any, methodName: string, config: CordovaOptions, args: IArguments | any[]): any;
