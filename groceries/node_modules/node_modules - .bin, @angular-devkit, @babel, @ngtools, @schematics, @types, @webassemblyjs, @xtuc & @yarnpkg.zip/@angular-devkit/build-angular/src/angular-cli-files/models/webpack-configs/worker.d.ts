import { Configuration } from 'webpack';
import { WebpackConfigOptions } from '../build-options';
export declare function getWorkerConfig(wco: WebpackConfigOptions): Configuration;
